import enUS from './en-us'
// import '../assetshome/js/jquery-3.5.1.min.js'
// import '../assetshome/js/bootstrap.bundle.min.js'
// import '../assetshome/vendor/owl-carousel/js/owl.carousel.min.js'
// import '../assetshome/vendor/wow/wow.min.js'
// import '../assetshome/js/mobster.js'

export default {
  'en-us': enUS
}
